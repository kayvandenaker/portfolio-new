"use client";

import Home from './components/Home.js'

export default function Page() {
  return (
    <Home/>
  )
}